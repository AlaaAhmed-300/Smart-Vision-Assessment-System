#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include "BluetoothSerial.h"
#include <WiFi.h>
#include <PubSubClient.h> 
#include <Preferences.h> 

BluetoothSerial SerialBT;
Preferences preferences; 

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define i2c_Address 0x3c

Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const int btnUP = 12, btnDOWN = 13, btnLEFT = 14, btnRIGHT = 27;

const char* ssid = "ssid";        
const char* password = "password";  

const char* mqttServer = "192.168.0.101";
const int mqttPort = 1883;
const char* mqttTopic = "vision/test/result"; 
WiFiClient espClient;
PubSubClient client(espClient);

String snellen[] = {"6/60", "6/36", "6/24", "6/18", "6/12", "6/9", "6/6"};
int textSizes[] = {6, 5, 4, 3, 2, 1, 1};

int level = 0;
int attempts = 0;
int correctInLevel = 0;
int currentDir = 0;
bool isDone = false;

unsigned long lastDebounceTime = 0;
const unsigned long debounceDelay = 200; 
unsigned long wifiReconnectTimer = 0;

void showStartScreen();
void finishTest(bool win);
void sendDataToMQTT(String result);
void drawStatusBar();
bool readButtonsNonBlocking(int &pressedBtn);
void reconnectMQTT();

void setup() {
  Serial.begin(115200);
  
  if (!SerialBT.begin("Vision_System_BT")) {
    Serial.println("BT Error");
  } else {
    Serial.println("Bluetooth Ready!");
  }

  WiFi.setAutoReconnect(true);
  WiFi.persistent(true);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");
  
  unsigned long startAttemptTime = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - startAttemptTime < 10000) {
    delay(500);
    Serial.print(".");
  }
  
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi Connected!");
    Serial.print("ESP32 IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi Connection Failed!");
  }

  client.setServer(mqttServer, mqttPort);

  pinMode(btnUP, INPUT_PULLUP);
  pinMode(btnDOWN, INPUT_PULLUP);
  pinMode(btnLEFT, INPUT_PULLUP);
  pinMode(btnRIGHT, INPUT_PULLUP);

  display.begin(i2c_Address, true);
  display.setTextColor(SH110X_WHITE);
  randomSeed(analogRead(34));

  preferences.begin("vision_app", true);
  String lastSavedResult = preferences.getString("last_res", "NONE");
  preferences.end();
  Serial.println("Last Saved Result in Flash: " + lastSavedResult);

  showStartScreen();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED && millis() - wifiReconnectTimer > 10000) {
    wifiReconnectTimer = millis();
    WiFi.reconnect();
  }

  if (WiFi.status() == WL_CONNECTED) {
    if (!client.connected()) {
      reconnectMQTT();
    }
    client.loop(); 
  }

  if (isDone) {
    int btn = -1;
    if (readButtonsNonBlocking(btn)) {
      level = 0;
      attempts = 0;
      correctInLevel = 0;
      isDone = false;
      showStartScreen();
    }
    return;
  }

  currentDir = random(0, 4);

  display.clearDisplay();
  drawStatusBar();

  display.setTextSize(1);
  display.setCursor(0, 10);
  display.print("Target: ");
  display.print(snellen[level]);

  display.setRotation(currentDir);
  display.setTextSize(textSizes[level]);

  if (currentDir == 0 || currentDir == 2) {
    display.setCursor(42, 22);
  } else {
    display.setCursor(22, 42);
  }

  display.print("E");
  display.setRotation(0);
  display.display();

  int choice = -1;
  while (choice == -1) {
    readButtonsNonBlocking(choice);
  }

  attempts++;
  if (choice == currentDir) correctInLevel++;

  if (attempts >= 3) {
    if (correctInLevel >= 2) {
      if (level == 6) {
        finishTest(true);
      } else {
        level++;
        attempts = 0;
        correctInLevel = 0;
      }
    } else {
      finishTest(false);
    }
  }
}

void reconnectMQTT() {
  if (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    String clientId = "ESP32Client-" + String(random(0xffff), HEX);
    if (client.connect(clientId.c_str())) {
      Serial.println("connected to MQTT Broker!");
    } else {
      Serial.print("failed, rc=");
      Serial.println(client.state());
    }
  }
}

bool readButtonsNonBlocking(int &pressedBtn) {
  if (millis() - lastDebounceTime < debounceDelay) return false;

  if (digitalRead(btnUP) == LOW) { pressedBtn = 3; lastDebounceTime = millis(); return true; }
  if (digitalRead(btnDOWN) == LOW) { pressedBtn = 1; lastDebounceTime = millis(); return true; }
  if (digitalRead(btnLEFT) == LOW) { pressedBtn = 2; lastDebounceTime = millis(); return true; }
  if (digitalRead(btnRIGHT) == LOW) { pressedBtn = 0; lastDebounceTime = millis(); return true; }

  return false;
}

void drawStatusBar() {
  display.setTextSize(1);
  display.setCursor(85, 0);
  if (WiFi.status() == WL_CONNECTED) {
    display.print("[WiFi]");
  } else {
    display.print("[NO-WF]");
  }
}

void showStartScreen() {
  display.clearDisplay();
  drawStatusBar();
  display.setTextSize(1);
  display.setCursor(10, 15);
  display.print("NEAR VISION SYSTEM");
  display.setCursor(10, 32);
  display.print("Dist: 35-40 cm");
  display.setCursor(10, 48);
  display.print("Press Any to Start");
  display.display();
  
  int tempBtn = -1;
  while (!readButtonsNonBlocking(tempBtn)) {
  }
}

void finishTest(bool win) {
  isDone = true;
  String resultText = "";

  if (win) {
    resultText = "6/6 PASS";
  } else {
    resultText = (level == 0) ? "< 6/60" : snellen[level - 1];
  }

  preferences.begin("vision_app", false);
  preferences.putString("last_res", resultText);
  preferences.end();

  SerialBT.println("Result: " + resultText);

  sendDataToMQTT(resultText);

  display.clearDisplay();
  drawStatusBar();
  display.setTextSize(1);
  display.setCursor(25, 12);
  display.print("TEST RESULT");
  display.setTextSize(2);
  display.setCursor(10, 32);

  if (win) {
    display.print("6/6 PASS");
  } else {
    if (level == 0) {
      display.setTextSize(1);
      display.print("VISION < 6/60");
    } else {
      display.print("Result: ");
      display.print(snellen[level - 1]);
    }
  }

  display.setTextSize(1);
  display.setCursor(10, 55);
  display.print("Press Any to Restart");
  display.display();
}

void sendDataToMQTT(String result) {
  if (WiFi.status() == WL_CONNECTED) {
    if (!client.connected()) {
      reconnectMQTT();
    }
    
    String jsonPayload = "{\"result\":\"" + result + "\",\"patient_id\":\"50\",\"name\":\" اسم المريض\"}";
    
    if (client.publish(mqttTopic, jsonPayload.c_str())) {
      Serial.println("Data successfully sent via MQTT!");
    } else {
      Serial.println("Failed to send data via MQTT");
    }
  } else {
    Serial.println("WiFi Disconnected, saved result locally in NVS.");
  }
}